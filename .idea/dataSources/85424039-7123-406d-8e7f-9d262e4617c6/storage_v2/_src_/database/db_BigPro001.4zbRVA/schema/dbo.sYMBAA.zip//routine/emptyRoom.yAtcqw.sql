create procedure emptyRoom
	 @hotelId char(3),@rTypeno char(3)
as
	select rno,rTypeName,rTypePrice
	from rooms,roomTypes
	where rooms.hotelId=@hotelId and rooms.rTypeno=@rTypeno and rooms.rTypeno = roomTypes.rTypeno and rno not in (
	select rno from check_in) 
	-- and rno not in (select rno from predict)
go


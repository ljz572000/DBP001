create procedure check_in_P
	@sum int output , @start_time datetime , @end_time datetime
as
	select rooms.rTypeno,roomTypes.rTypeName,sum(totalDay) as 入住天数
	from check_in,rooms,roomTypes,customers,hotels
	where customers.idCard = check_in.idCard and rooms.rTypeno=roomTypes.rTypeno and rooms.hotelId = check_in.hotelId and rooms.rno = check_in.rno
	and check_in.check_inTime >=@start_time and check_in.leftTime<=@end_time group by rooms.rTypeno,roomTypes.rTypeName
go

